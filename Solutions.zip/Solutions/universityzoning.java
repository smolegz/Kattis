import com.sun.jdi.ArrayReference;

import java.util.*;

public class universityzoning {

    public static void main(String[] args) {


    }

}
