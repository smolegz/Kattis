import java.util.*;
import java.io.*;

public class flippingpatties {
    public static class FastScanner {
        BufferedReader br = new BufferedReader(
                new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer("");

        String next() {
            while (!st.hasMoreTokens())
                try {
                    st = new StringTokenizer(br.readLine());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            return st.nextToken();
        }

        int nextInt() {
            return Integer.parseInt(next());
        }

        int[] readArray(int n) {
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
                a[i] = nextInt();
            return a;
        }

        long nextLong() {
            return Long.parseLong(next());
        }
    }

    public static void main(String[] args) throws Exception {
        FastScanner sc = new FastScanner();
        int n = sc.nextInt();
        int[] arr = new int[43201];
        int cook = 1;
        while (n-- > 0) {
            int d = sc.nextInt();
            int t = sc.nextInt();
            arr[t] +=1;
            cook = Math.max(cook, arr[t]/2 + (arr[t]%2 == 0 ? 0 : 1));
            arr[t-d] += 1;
            cook = Math.max(cook, arr[t-d]/2 + (arr[t-d]%2 == 0 ? 0 : 1));
            arr[t-2*d] += 1;
            cook = Math.max(cook, arr[t-2*d]/2 + (arr[t-2*d]%2 == 0 ? 0 : 1));
        }
        System.out.print(cook);
    }

}
